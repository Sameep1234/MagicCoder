#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<windows.h>
#include<stdlib.h>

void displayBorder();
void loginAdmin();
void customerSearch();
void search(int storeChoice);
void Delete(int storeChoice);
void update(int storeChoice);
void add(int storeChoice);
void admin(char loginId[40]);
int loginCheck(char loginId[], char password[]);
void setxy (int x, int y);


COORD c = {0, 0};

FILE *fp[9];
FILE *tempfp;

int main()
{
	displayBorder();
	printf("	WELCOME TO DRUG/MEDICINE SEARCH DIRECTORY  ");
	displayBorder();
	int choice;
	char ch;
	char nameMedicalStore[10];
	char loginId[40];
	char password[10];
	printf("\n1. Customer\n\n2. Admin");
	while(choice!=1 && choice!=2)
	{
		printf("\n\nEnter you choice: ");
		scanf("%d",&choice);
		if(choice==1)
		{
			system("color 7");
			customerSearch();
		}
		else if(choice==2)
		{
			system("color 7");
			loginAdmin();
		}
		else
		{
			printf("\nInvalid Input!");
		}
	}
	return 0;
}


void loginAdmin()
{
	
	int temp,flag=0,j=0;
	system("cls");
	//system("color B");
	displayBorder();
	printf("	 Welcome to admin login page	");
	displayBorder();
	system("color 7");
	char loginId[40],password[11];
	int i;
	printf("\nLoginId = ");
	scanf(" %s",&loginId);
	//sgetch();
	printf("\nPassword (10 digit) = ");
	for(i=0;i<10;i++)
	{
		password[i] = getch();
		j++;
		if(password[i] == 13)
		{
			flag = 1;
			break;
		}
		else if(password[i]  == 8)
		{
			
		}
		printf("*");
	}
	if(flag==0)
	{
		getch();
	}
	temp = loginCheck(loginId,password);
	if(temp == 1)
	{
		admin(loginId);
	}
	else
	{
		printf("\nUsername or Password is incorrect");
	}
}

void admin(char loginId[]){
	int choice=-1;
	int storeChoice=0;
	system("cls");
	displayBorder();
	printf("	Welcome %s  ",loginId);
	displayBorder();
	system("color 7");
	printf("\n\nSelect one of the following stores: ");
	while(storeChoice<=0 || storeChoice>10)
	{
		printf("\n\n1.Apollo Pharmacy\n2.Deepak Medical Store\n3.Med Card\n4.Narayandas Pharmacy\n5.Paras Medicals\n6.Parth Pharmacy\n7.Planet Health\n8.Sunny Medicals\n9.Sunrise Medicals\n10.Go to previous page\n");
		printf("\nEnter your choice.");
		scanf("%d",&storeChoice);
		if(storeChoice==10)
		{
			loginAdmin();
			break;
		}
	}
	system("cls");
	while(choice!=1 && choice!=2 && choice!=3 && choice!=4)
	{
	
		displayBorder();
		switch(storeChoice)
		{
			case 1:
				printf("	Welcome to Apollo Pharmacy, %s",loginId);
				break;
			case 2:
				printf("	Welcome to Deepak Medcial Stores, %s",loginId);
				break;
			case 3:
				printf("	Welcome to MedCart, %s",loginId);
				break;			
			case 4:
				printf("	Welcome to Narayandas Pharmacy, %s",loginId);
				break;
			case 5:
				printf("	Welcome to Paras medicals, %s",loginId);
				break;
			case 6:
				printf("	Welcome to Parth Pharmacy, %s",loginId);
				break;
			case 7:
				printf("	Welcome to Planet Health, %s",loginId);
				break;
			case 8:
				printf("	Welcome to Sunny Medicals, %s",loginId);
				break;
			case 9:
				printf("	Welcome to Sunrise Medicals, %s",loginId);
				break;
		}
		displayBorder();
		system("color 7");
		printf("\n\nWhat do you want to do?\n");
		printf("\n\n1. Search stock\n2. Add Medicine\n3. Update a medicine\n4. Delete a medicine record\n5. Go to previous page\n");
		printf("\nEnter your choice.");
		scanf("%d",&choice);
		if(choice==1)
		{
			search(storeChoice);
		}
		else if(choice==2)
		{
			add(storeChoice);
		}
		else if(choice==3)
		{
			update(storeChoice);
		}
		else if(choice==4)
		{
			Delete(storeChoice);
		}
		else if(choice==5)
		{
			admin(loginId);
			break;
		}
		else
		{
			printf("\nCheck your Input again.");
		}
	}
}


int loginCheck(char loginId[], char password[])
{
	FILE *fp;
	int a,b;
	char *floginId, *fpassword, *token;
	int temp = 0;
	char str[40] = "", s[2] = " ";
	fp = fopen("adminPassword.txt","r");
	while(fgets(str, 40, fp)!=NULL)
	{
		floginId = strtok(str, s);
		fpassword = strtok(NULL, s);
		fpassword[strlen(fpassword) - 1] = '\0';
		if(strcmp(loginId,"guest") == 0)
		{
			if(strcmp(password,fpassword)==1)
			{
				temp = 1;
			}
		}
		if((strcmp(loginId, floginId) == 0) && (strcmp(password, fpassword) == 0))
		{
			temp = 1;
		}
	}
	fclose(fp);
	return temp;
}


void customerSearch()
{
	int finalChoice = 1;
	int flag[9],i = 0;
	char flag2[40];
	char searchMedicine[40],str1[200],*token,*temp,*quantity,*price;
	while(finalChoice == 1)
	{
		system("cls");
		displayBorder();
		printf("	 WELCOME TO MEDICINE SEARCH PAGE   ");
		displayBorder();
		system("color 7");
		printf("\nEnter the medicine you want to search: ");
		scanf("%s",searchMedicine);
		for(i=0;i<sizeof(searchMedicine);i++)
		{
			flag2[i] = tolower(searchMedicine[i]);
		}
		strcpy(searchMedicine,flag2);
		//printf("The entered Medicine is: %s\n\n",searchMedicine);
		fp[0] = fopen("ApolloPharmacy.txt","r");
		fp[1] = fopen("DeepakMedicalStore.txt","r");
		fp[2] = fopen("MedCart.txt","r");
		fp[3] = fopen("NarayandasPharmacy.txt","r");
		fp[4] = fopen("ParasMedical.txt","r");
		fp[5] = fopen("ParthPharmacy.txt","r");
		fp[6] = fopen("PlanetHealth.txt","r");
		fp[7] = fopen("SunnyMedical.txt","r");
		fp[8] = fopen("SunriseMedical.txt","r");
		while(fgets(str1, 200, fp[0])!=NULL)
		{
			token = strtok(str1," ");
			temp = strtok(NULL,"	");
			quantity = strtok(NULL,"	");
			price = strtok(NULL, "	");
			if(strcmp(token,searchMedicine)==0)
			{
				printf("The name of the store is Apollo Pharmacy.\n\n");
				printf("The address of the store is: Akshar Arcade, 33, NEAR, VIJAY CHAR RASTA, Ahmedabad, Gujarat 380009");
				printf("\nFull name of medicine is: %s %s\n\n",token,temp);
				printf("The quantity(in strips) is %s\n\n",quantity);
				printf("The price per strip is %s\n\n",price);
				flag[0] = 1;
			}
		}
		while(fgets(str1, 200, fp[1])!=NULL)
		{
			int a;
			token = strtok(str1," ");
			temp = strtok(NULL,"	");
			quantity = strtok(NULL,"	");
			price = strtok(NULL, "	");
			a = strcmp(token,searchMedicine);
			if(strcmp(token,searchMedicine)==0)
			{
				printf("The name of the store is Deepak Medical stores.\n\n");
				printf("The address of the store is: Ishwar Complex, opp, Sardar Patel Stadium Rd, Kamla Society, Hindu Colony, Navrangpura, Ahmedabad, Gujarat 380009\n\n");
				printf("\nFull name of medicine is: %s %s\n\n",token,temp);
				printf("The quantity(in strips) is %s\n\n",quantity);
				printf("The price per strip is %s\n\n",price);
				flag[1] = 1;
			}
		}
		while(fgets(str1, 200, fp[2])!=NULL)
		{
			token = strtok(str1," ");
			temp = strtok(NULL,"	");
			quantity = strtok(NULL,"	");
			price = strtok(NULL, "	");
			if(strcmp(token,searchMedicine)==0)
			{
				printf("The name of the store is MedCart.\n\n");
				printf("The address of the store is: First floor, Ishwar complex, above Deepak medical, opp, Sardar Patel Stadium Rd, Ahmedabad, Gujarat 380009\n\n");
				printf("\nFull name of medicine is: %s %s\n\n",token,temp);
				printf("The quantity(in strips) is %s\n\n",quantity);
				printf("The price per strip is %s\n\n",price);
				flag[2] = 1;
			}
		}
		while(fgets(str1, 200, fp[3])!=NULL)
		{
			token = strtok(str1," ");
			temp = strtok(NULL,"	");
			quantity = strtok(NULL,"	");
			price = strtok(NULL, "	");
			if(strcmp(token,searchMedicine)==0)
			{
				printf("The name of the store is Narayandas Pharmacy.\n\n");
				printf("The address of the store is: 100 Feet Anand Nagar Rd, Jodhpur Village, Ahmedabad, Gujarat 380015\n\n");
				printf("\nFull name of medicine is: %s %s\n\n",token,temp);
				printf("The quantity(in strips) is %s\n\n",quantity);
				printf("The price per strip is %s\n\n",price);
				flag[3] = 1;
			}	
		}
		while(fgets(str1, 200, fp[4])!=NULL)
		{
			token = strtok(str1," ");
			temp = strtok(NULL,"	");
			quantity = strtok(NULL,"	");
			price = strtok(NULL, "	");
			if(strcmp(token,searchMedicine)==0)
			{
				printf("The name of the store is Paras Medical.\n\n");
				printf("The address of the store is: 6, MIllenium Plaza,Premchandanagar Road, opposite Swaminarayan Temple, Ahmedabad, Gujarat 380015\n\n");
				printf("\nFull name of medicine is: %s %s\n\n",token,temp);
				printf("The quantity(in strips) is %s\n\n",quantity);
				printf("The price per strip is %s\n\n",price);
				flag[4] = 1;
			}	
		}
		while(fgets(str1, 200, fp[5])!=NULL)
		{
			token = strtok(str1," ");
			temp = strtok(NULL,"	");
			quantity = strtok(NULL,"	");
			price = strtok(NULL, "	");
			if(strcmp(token,searchMedicine)==0)
			{
				printf("The name of the store is Parth Pharmacy.\n\n");
				printf("The address of the store is: 1, IOC Rd, Shubh Sonal Society, Padam Prabhu Nagar, D-Cabin, Sabarmati, Ahmedabad, Gujarat 380019\n\n");
				printf("\nFull name of medicine is: %s %s\n\n",token,temp);
				printf("The quantity(in strips) is %s\n\n",quantity);
				printf("The price per strip is %s\n\n",price);
				flag[5] = 1;
			}
		}
		while(fgets(str1, 200, fp[6])!=NULL)
		{
			token = strtok(str1," ");
			temp = strtok(NULL,"	");
			quantity = strtok(NULL,"	");
			price = strtok(NULL, "	");
			if(strcmp(token,searchMedicine)==0)
			{
				printf("The name of the store is Planet Health.\n\n");
				printf("The address of the store is: Sagar, Ambavadi, Opposite Stock Exchange, near Sahajanand Collage, Ambawadi, Ahmedabad, Gujarat 380015\n\n");
				printf("\nFull name of medicine is: %s %s\n\n",token,temp);
				printf("The quantity(in strips) is %s\n\n",quantity);
				printf("The price per strip is %s\n\n",price);
				flag[6] = 1;
			}	
		}
		while(fgets(str1, 200, fp[7])!=NULL)
		{
			token = strtok(str1," ");
			temp = strtok(NULL,"	");
			price = strtok(NULL, "	");
			if(strcmp(token,searchMedicine)==0)
			{
				printf("The name of the store is Sunny Medicals.\n\n");
				printf("The address of the store is: Delhi Darwaja, BG Tower, 101, ground floor, Shahibaug Rd, Ahmedabad, Gujarat 380004.\n\n");
				printf("\nFull name of medicine is: %s %s\n\n",token,temp);
				printf("The quantity(in strips) is %s\n\n",quantity);
				printf("The price per strip is %s\n\n",price);
				flag[7] = 1;
			}	
		}
		while(fgets(str1, 200, fp[8])!=NULL)
		{
			token = strtok(str1," ");
			temp = strtok(NULL,"	");
			quantity = strtok(NULL,"	");
			price = strtok(NULL, "	");
			if(strcmp(token,searchMedicine)==0)
			{
				printf("The name of the store is Sunrise Medicals.\n\n");
				printf("The address of the store is: 7, Bhaktinagar Shopping Centre, Megani Nagar, Gurukul Road, Near Sunset Row House, Megani Nagar, Ahmedabad, Gujarat 380052\n\n");
				printf("\nFull name of medicine is: %s %s\n\n",token,temp);
				printf("The quantity(in strips) is %s\n\n",quantity);
				printf("The price per strip is %s\n\n",price);
				flag[8] = 1;
			}	
		}
		if(flag[0]!=1 && flag[1]!=1 && flag[2]!=1 && flag[3]!=1 && flag[4]!=1 && flag[5]!=1 && flag[6]!=1 && flag[7]!=1 && flag[8]!=1)
		{
			printf("NO RESULTS FOUND\n\n");
		}
		for(i=0;i<9;i++)
		{
			fclose(fp[i]);
		}
		printf("Press 1 for continuing search or 2 to exit.\n");
		scanf("%d",&finalChoice);
	}
	if(finalChoice==2)
	{
		system("cls");
		for(i=0; i<35; i++)
  		{
  		
    	system("color B");
    	setxy(i, 4);
    	printf(" THANK YOU, VISIT AGAIN.....");
    	setxy(i-3, 4); //For clearing previous position of arrow
		Sleep(100);
		}
	}
}


void search(int storeChoice)
{
	char flag2[40],searchMedicine[50];
	int flag = 0;
	int a,i,finalChoice = 1;
	while(finalChoice == 1)
	{
		system("cls");
		displayBorder();
		printf("	WELCOME TO SEARCH STOCK DIRECTORY  ");
		displayBorder();
		system("color 7");
		printf("\n\nEnter the medicine to search: ");
		scanf("%s",searchMedicine);
		for(i=0;i<sizeof(searchMedicine);i++)
		{
			flag2[i] = tolower(searchMedicine[i]);
		}
		strcpy(searchMedicine,flag2);
		char str[200],*flag2[200],*token,*temp,*quantity,*price;
		switch(storeChoice)
		{
			case 1:
				fp[0] = fopen("ApolloPharmacy.txt","r");
				while(fgets(str, 200, fp[0])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, searchMedicine) == 0)
					{
						printf("Stock of %s %s available is %s strips\n",token,temp,quantity);
						flag = 1;
					}
				}
				if(flag != 1)
				{
					printf("NO RESULTS FOUND");
				}
				fclose(fp[0]);
				break;
			case 2:
				fp[1] = fopen("Deepakmedicalstore.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[1])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, searchMedicine) == 0)
					{
						printf("Stock of %s %s available is %s strips\n",token,temp,quantity);
						flag = 1;
					}
					
				}
				if(flag != 1)
				{
					printf("NO RESULTS FOUND");
				}
				fclose(fp[1]);
				fclose(tempfp);
				break;
			case 3:
				fp[2] = fopen("MedCart.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[2])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, searchMedicine) == 0)
					{
						printf("Stock of %s %s available is %s strips\n",token,temp,quantity);
						flag = 1;
					}
				}
				if(flag != 1)
				{
					printf("NO RESULTS FOUND");
				}
				fclose(fp[2]);
				fclose(tempfp);
				break;
			case 4:
				fp[3] = fopen("NarayandasPharmacy.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[3])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, searchMedicine) == 0)
					{
						printf("Stock of %s %s available is %s strips\n",token,temp,quantity);
						flag = 1;
					}
				}
				if(flag != 1)
				{
					printf("NO RESULTS FOUND");
				}
				fclose(fp[3]);
				fclose(tempfp);
				break;
			case 5:
				fp[4] = fopen("ParasMedical.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[4])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, searchMedicine) == 0)
					{
						printf("Stock of %s %s available is %s strips\n",token,temp,quantity);
						flag = 1;
					}
				}
				if(flag != 1)
				{
					printf("NO RESULTS FOUND");
				}
				fclose(fp[4]);
				fclose(tempfp);
				break;
			case 6:
				fp[5] = fopen("ParthPharmacy.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[5])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, searchMedicine) == 0)
					{
						printf("Stock of %s %s available is %s strips\n",token,temp,quantity);
						flag = 1;
					}
				}
				if(flag != 1)
				{
					printf("NO RESULTS FOUND");
				}
				fclose(fp[5]);
				fclose(tempfp);
				break;
			case 7:
				fp[6] = fopen("PlanetHealth.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[6])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, searchMedicine) == 0)
					{
						printf("Stock of %s %s available is %s strips\n",token,temp,quantity);
						flag = 1;
					}
				}
				if(flag != 1)
				{
					printf("NO RESULTS FOUND");
				}
				fclose(fp[6]);
				fclose(tempfp);
				break;
			case 8:
				fp[7] = fopen("SunnyMedical.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[7])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, searchMedicine) == 0)
					{
						printf("Stock of %s %s available is %s strips\n",token,temp,quantity);
						flag = 1;
					}
				}
				if(flag != 1)
				{
					printf("NO RESULTS FOUND");
				}
				fclose(fp[7]);
				fclose(tempfp);
				break;
			case 9:
				fp[8] = fopen("SunriseMedical.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[8])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, searchMedicine) == 0)
					{
						printf("Stock of %s %s available is %s strips\n",token,temp,quantity);
						flag = 1;
					}
				}			
				if(flag != 1)
				{
					printf("NO RESULTS FOUND");
				}
				fclose(fp[8]);
				fclose(tempfp);
				break;
		}
		printf("\n\nPress 1 to continue search or 2 to exit.\n");
		scanf("%d",&finalChoice);
	}
	if(finalChoice == 2)
	{
		system("cls");
		for(i=0; i<35; i++)
  		{
  			system("color B");
	    	setxy(i, 4);
	    	printf(" THANK YOU.....");
	    	setxy(i-3, 4); //For clearing previous position of arrow
			Sleep(100);
		}
	}
}


void Delete(int storeChoice)
{
	int finalChoice = 1;
	char flag2[40],deleteMedicine[50];
	int a,i;
	while(finalChoice == 1)
	{
		system("cls");
		displayBorder();
		printf("	WELCOME TO DELETE MEDICINE DIRECTORY  ");
		displayBorder();
		system("color 7");
		printf("\n\nEnter the medicine you want to delete: ");
		scanf("%s",deleteMedicine);
		for(i=0;i<sizeof(deleteMedicine);i++)
		{
			flag2[i] = tolower(deleteMedicine[i]);
		}
		strcpy(deleteMedicine,flag2);
		char str[200], str1[200],*token,*temp,*quantity,*price;
		switch(storeChoice)
		{
			case 1:
				fp[0] = fopen("ApolloPharmacy.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[0])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, deleteMedicine) == 0)
					{
						//printf("The string is %s %s %s %s\n\n",token,temp,quantity,price);
					}
					else
					{
						fprintf(tempfp,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[0]);
				fclose(tempfp);
				remove("ApolloPharmacy.txt");
				rename("temp.txt","ApolloPharmacy.txt");
				printf("Data Deleted successfully.\n");
				break;
			case 2:
				fp[1] = fopen("Deepakmedicalstore.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[1])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, deleteMedicine) == 0)
					{
						//printf("The string is %s %s %s %s\n\n",token,temp,quantity,price);
					}
					else
					{
						fprintf(tempfp,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[1]);
				fclose(tempfp);
				remove("Deepakmedicalstore.txt");
				rename("temp.txt","Deepakmedicalstore.txt");
				printf("Data Deleted successfully.\n");
				break;
			case 3:
				fp[2] = fopen("MedCart.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[2])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, deleteMedicine) == 0)
					{
						//printf("The string is %s %s %s %s\n\n",token,temp,quantity,price);
					}
					else
					{
						fprintf(tempfp,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[2]);
				fclose(tempfp);
				remove("MedCart.txt");
				rename("temp.txt","MedCart.txt");
				printf("Data Deleted successfully.\n");
				break;
			case 4:
				fp[3] = fopen("NarayandasPharmacy.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[3])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, deleteMedicine) == 0)
					{
						//printf("The string is %s %s %s %s\n\n",token,temp,quantity,price);
					}
					else
					{
						fprintf(tempfp,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[3]);
				fclose(tempfp);
				remove("NarayandasPharmacy.txt");
				rename("temp.txt","NarayandasPharmacy.txt");
				printf("Data Deleted successfully.\n");
				break;
			case 5:
				fp[4] = fopen("ParasMedical.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[4])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, deleteMedicine) == 0)
					{
						//printf("The string is %s %s %s %s\n\n",token,temp,quantity,price);
					}
					else
					{
						fprintf(tempfp,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[4]);
				fclose(tempfp);
				remove("ParasMedical.txt");
				rename("temp.txt","ParasMedical.txt");
				printf("Data Deleted successfully.\n");
				break;
			case 6:
				fp[5] = fopen("ParthPharmacy.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[5])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, deleteMedicine) == 0)
					{
						//printf("The string is %s %s %s %s\n\n",token,temp,quantity,price);
					}
					else
					{
						fprintf(tempfp,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[5]);
				fclose(tempfp);
				remove("ParthPharmacy.txt");
				rename("temp.txt","ParthPharmacy.txt");
				printf("Data Deleted successfully.\n");
				break;
			case 7:
				fp[6] = fopen("PlanetHealth.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[6])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, deleteMedicine) == 0)
					{
						//printf("The string is %s %s %s %s\n\n",token,temp,quantity,price);
					}
					else
					{
						fprintf(tempfp,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[6]);
				fclose(tempfp);
				remove("PlanetHealth.txt");
				rename("temp.txt","PlanetHealth.txt");
				printf("Data Deleted successfully.\n");
				break;
			case 8:
				fp[7] = fopen("SunnyMedical.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[7])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, deleteMedicine) == 0)
					{
						//printf("The string is %s %s %s %s\n\n",token,temp,quantity,price);
					}
					else
					{
						fprintf(tempfp,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[7]);
				fclose(tempfp);
				remove("SunnyMedical.txt");
				rename("temp.txt","SunnyMedical.txt");
				printf("Data Deleted successfully.\n");
				break;
			case 9:
				fp[8] = fopen("SunriseMedical.txt","r");
				tempfp = fopen("temp.txt","w");
				while(fgets(str, 200, fp[8])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, deleteMedicine) == 0)
					{
						//printf("The string is %s %s %s %s\n\n",token,temp,quantity,price);
					}
					else
					{
						fprintf(tempfp,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[8]);
				fclose(tempfp);
				remove("SunriseMedical.txt");
				rename("temp.txt","SunriseMedical.txt");
				printf("Data Deleted successfully.\n");
				break;
		}
		printf("\n\nPress 1 to continue or 2 to exit.\n");
		scanf("%d",&finalChoice);

	}
	if(finalChoice == 2)
	{
		system("cls");
		for(i=0; i<35; i++)
  		{
  			system("color B");
	    	setxy(i, 4);
	    	printf(" THANK YOU.....");
	    	setxy(i-3, 4); //For clearing previous position of arrow
			Sleep(100);
		}
	}
}

void update(int storeChoice)
{
	FILE *updt;
	int n;
	//tu=fopen("trialupdt.txt","a");
	int finalChoice = 1;
	char flag2[40],updateMedicine[50];
	int a,i;
	while(finalChoice == 1)
	{
		system("cls");
		displayBorder();
		printf("	WELCOME TO UPDATE MEDICINE DIRECTORY  ");
		displayBorder();
		system("color 7");
		printf("\n\nEnter the medicine you want to update: ");
		scanf("%s",updateMedicine);
		for(i=0;i<sizeof(updateMedicine);i++)
		{
			flag2[i] = tolower(updateMedicine[i]);
		}
		strcpy(updateMedicine,flag2);
		char str[200], str1[200],*token,*temp,*quantity,*price,cost[20],token1[20],temp1[20],quantity1[10],price1[10];
		switch(storeChoice)
		{
			case 1:
				updt = fopen("temp.txt","w");
				fp[0] = fopen("ApolloPharmacy.txt","r");
			
				while(fgets(str, 200, fp[0])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, updateMedicine) == 0)
					{
						printf("Medicine name is: %s %s",token,temp);
						printf("\nPress 1 to update this medicine or 2 to skip this medicine: ");
						printf("\nEnter your choice: \n");
						scanf("%d",&n);
						if(n==1)
						{
							strcpy(token1,token);
							fprintf(updt,"%s",token1);
							strcpy(temp1,temp);
							fprintf(updt," %s",temp1);
							printf("\nEnter the updated quantity:");
							scanf("	%s",quantity1);
							fprintf(updt,"	%s",quantity1);
							printf("Enter updated price per strip:");
							scanf("%s",price1);
							fprintf(updt,"	%s\n",price1);
						}
					}
					else
					{
						fprintf(updt,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[0]);
				fclose(updt);
				remove("ApolloPharmacy.txt");
				rename("temp.txt","ApolloPharmacy.txt");
				printf("Data updated successfully.\n");
				break;
			case 2:
				updt=fopen("temp.txt","w");
				fp[1] = fopen("Deepakmedicalstore.txt","r");
				while(fgets(str, 200, fp[1])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, updateMedicine) == 0)
					{
						printf("Medicine name is: %s %s",token,temp);
						printf("\nPress 1 to update this medicine or 2 to skip this medicine: ");
						printf("\nEnter your choice: \n");
						scanf("%d",&n);
						if(n==1)
						{
							strcpy(token1,token);
							fprintf(updt,"%s",token1);
							strcpy(temp1,temp);
							fprintf(updt," %s",temp1);
							printf("Enter the updated quantity:");
							scanf("	%s",quantity1);
							fprintf(updt,"	%s",quantity1);
							printf("Enter updated price per strip:");
							scanf("%s",price1);
							fprintf(updt,"	%s\n",price1);	
						}
					}
					else
					{
						fprintf(updt,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[1]);
				fclose(updt);
				remove("Deepakmedicalstore.txt");
				rename("temp.txt","Deepakmedicalstore.txt");
				printf("Data updated successfully.\n");
				break;
			case 3:
				updt = fopen("temp.txt","w");
				fp[2] = fopen("MedCart.txt","r");
				while(fgets(str, 200, fp[2])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, updateMedicine) == 0)
					{
						printf("Medicine name is: %s %s",token,temp);
						printf("\nPress 1 to update this medicine or 2 to skip this medicine: ");
						printf("\nEnter your choice: \n");
						scanf("%d",&n);
						if(n==1)
						{
							strcpy(token1,token);
							fprintf(updt,"%s",token1);
							strcpy(temp1,temp);
							fprintf(updt," %s",temp1);
							printf("Enter the updated quantity:");
							scanf("	%s",quantity1);
							fprintf(updt,"	%s",quantity1);
							printf("Enter updated price per strip:");
							scanf("%s",price1);
							fprintf(updt,"	%s\n",price1);
						}
					}
					else
					{
						fprintf(updt,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[2]);
				fclose(updt);
				remove("MedCart.txt");
				rename("temp.txt","MedCart.txt");
				printf("Data updated successfully.\n");
				break;
			case 4:
				updt = fopen("temp.txt","w");
				fp[3] = fopen("NarayandasPharmacy.txt","r");
				while(fgets(str, 200, fp[3])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, updateMedicine) == 0)
					{
						printf("Medicine name is: %s %s",token,temp);
						printf("\nPress 1 to update this medicine or 2 to skip this medicine: ");
						printf("\nEnter your choice: \n");
						scanf("%d",&n);
						if(n==1)
						{
							strcpy(token1,token);
							fprintf(updt,"%s",token1);
							strcpy(temp1,temp);
							fprintf(updt," %s",temp1);
							printf("Enter the updated quantity:");
							scanf("	%s",quantity1);
							fprintf(updt,"	%s",quantity1);
							printf("Enter updated price per strip:");
							scanf("%s",price1);
							fprintf(updt,"	%s\n",price1);
						}
					}
					else
					{
						fprintf(updt,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[3]);
				fclose(updt);
				remove("NarayandasPharmacy.txt");
				rename("temp.txt","NarayandasPharmacy.txt");
				printf("Data updated successfully.\n");
				break;
			case 5:
				updt = fopen("temp.txt","w");
				fp[4] = fopen("ParasMedical.txt","r");
				while(fgets(str, 200, fp[4])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, updateMedicine) == 0)
					{
						printf("Medicine name is: %s %s",token,temp);
						printf("\nPress 1 to update this medicine or 2 to skip this medicine: ");
						printf("\nEnter your choice: \n");
						scanf("%d",&n);
						if(n==1)
						{
							strcpy(token1,token);
							fprintf(updt,"%s",token1);
							strcpy(temp1,temp);
							fprintf(updt," %s",temp1);
							printf("Enter the updated quantity:");
							scanf("	%s",quantity1);
							fprintf(updt,"	%s",quantity1);
							printf("Enter updated price per strip:");
							scanf("%s",price1);
							fprintf(updt,"	%s\n",price1);
						}	
					}
					else
					{
						fprintf(updt,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[4]);
				fclose(updt);
				remove("ParasMedical.txt");
				rename("temp.txt","ParasMedical.txt");
				printf("Data updated successfully.\n");
				break;
			case 6:
				updt = fopen("temp.txt","w");
				fp[5] = fopen("ParthPharmacy.txt","r");
				while(fgets(str, 200, fp[5])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, updateMedicine) == 0)
					{
						printf("Medicine name is: %s %s",token,temp);
						printf("\nPress 1 to update this medicine or 2 to skip this medicine: ");
						printf("\nEnter your choice: \n");
						scanf("%d",&n);
						if(n==1)
						{
							strcpy(token1,token);
							fprintf(updt,"%s",token1);
							strcpy(temp1,temp);
							fprintf(updt," %s",temp1);
							printf("Enter the updated quantity:");
							scanf("	%s",quantity1);
							fprintf(updt,"	%s",quantity1);
							printf("Enter updated price per strip:");
							scanf("%s",price1);
							fprintf(updt,"	%s\n",price1);
						}
					}
					else
					{
						fprintf(updt,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[5]);
				fclose(updt);
				remove("ParthPharmacy.txt");
				rename("temp.txt","ParthPharmacy.txt");
				printf("Data updated successfully.\n");
				break;
			case 7:
				updt = fopen("temp.txt","w");
				fp[6] = fopen("PlanetHealth.txt","r");
				while(fgets(str, 200, fp[6])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, updateMedicine) == 0)
					{
						printf("Medicine name is: %s %s",token,temp);
						printf("\nPress 1 to update this medicine or 2 to skip this medicine: ");
						printf("\nEnter your choice: \n");
						scanf("%d",&n);
						if(n==1)
						{
							strcpy(token1,token);
							fprintf(updt,"%s",token1);
							strcpy(temp1,temp);
							fprintf(updt," %s",temp1);
							printf("Enter the updated quantity:");
							scanf("	%s",quantity1);
							fprintf(updt,"	%s",quantity1);
							printf("Enter updated price per strip:");
							scanf("%s",price1);
							fprintf(updt,"	%s\n",price1);
						}
					}
					else
					{
						fprintf(updt,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[6]);
				fclose(updt);
				remove("PlanetHealth.txt");
				rename("temp.txt","PlanetHealth.txt");
				printf("Data updated successfully.\n");
				break;
			case 8:
				updt = fopen("temp.txt","w");
				fp[7] = fopen("SunnyMedical.txt","r");
				while(fgets(str, 200, fp[7])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, updateMedicine) == 0)
					{
						printf("Medicine name is: %s %s",token,temp);
						printf("\nPress 1 to update this medicine or 2 to skip this medicine: ");
						printf("\nEnter your choice: \n");
						scanf("%d",&n);
						if(n==1)
						{
							strcpy(token1,token);
							fprintf(updt,"%s",token1);
							strcpy(temp1,temp);
							fprintf(updt," %s",temp1);
							printf("Enter the updated quantity:");
							scanf("	%s",quantity1);
							fprintf(updt,"	%s",quantity1);
							printf("Enter updated price per strip:");
							scanf("%s",price1);
							fprintf(updt,"	%s\n",price1);
						}
					}
					else
					{
						fprintf(updt,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[7]);
				fclose(updt);
				remove("SunnyMedical.txt");
				rename("temp.txt","SunnyMedical.txt");
				printf("Data updated successfully.\n");
				break;
			case 9:
				updt = fopen("temp.txt","w");
				fp[8] = fopen("SunriseMedical.txt","r");
				while(fgets(str, 200, fp[8])!=NULL)
				{
					token = strtok(str," ");
					temp = strtok(NULL,"	");
					quantity = strtok(NULL,"	");
					price = strtok(NULL, "	");
					if(strcmp(token, updateMedicine) == 0)
					{
						printf("Medicine name is: %s %s",token,temp);
						printf("\nPress 1 to update this medicine or 2 to skip this medicine: ");
						printf("\nEnter your choice: \n");
						scanf("%d",&n);
						if(n==1)
						{
							strcpy(token1,token);
							fprintf(updt,"%s",token1);
							strcpy(temp1,temp);
							fprintf(updt," %s",temp1);
							printf("Enter the updated quantity:");
							scanf("	%s",quantity1);
							fprintf(updt,"	%s",quantity1);
							printf("Enter updated price per strip:");
							scanf("%s",price1);
							fprintf(updt,"	%s\n",price1);
						}
					}
					else
					{
						fprintf(updt,"%s %s	%s	%s",token,temp,quantity,price);
					}
				}
				fclose(fp[8]);
				fclose(updt);
				remove("SunriseMedical.txt");
				rename("temp.txt","SunriseMedical.txt");
				printf("Data updated successfully.\n");
				break;
		}
		printf("\n\nPress 1 to continue or 2 to exit.\n");
		scanf("%d",&finalChoice);

	}
	if(finalChoice == 2)
	{
		system("cls");
		for(i=0; i<35; i++)
  		{
  			system("color B");
	    	setxy(i, 4);
	    	printf(".....THANK YOU.....");
	    	setxy(i-3, 4); //For clearing previous position of arrow
			Sleep(100);
		}
	}
		
}


void add(int storeChoice)
{
	int finalChoice = 1;
	char flag2[40];
	int i;
	while(finalChoice == 1)
	{
		system("cls");
		displayBorder();
		printf("	WELCOME TO ADD MEDICINE DIRECTORY  ");
		displayBorder();
		system("color 7");
		printf("\nEnter the medicine/drug to add: ");
		char medicine[40];
		char tempMedicine[40];
		gets(tempMedicine);
		gets(medicine);
		//printf("Medicine is: %s",medicine);
		for(i=0;i<sizeof(medicine);i++)
		{
			flag2[i] = tolower(medicine[i]);
		}
		strcpy(medicine,flag2);
		char quantity[20];
		printf("\nEnter quantity of medicine: ");
		gets(quantity);
		char price[4];
		printf("\nEnter price of medicine per strip: ");
		gets(price);
		switch(storeChoice)
		{
			case 1:
				fp[0] = fopen("ApolloPharmacy.txt","a");
				fprintf(fp[0],"%s",medicine);
				fprintf(fp[0],"%s","	");
				fprintf(fp[0],"%s",quantity);
				fprintf(fp[0],"%s","	");
				fprintf(fp[0],"%s",price);
				fprintf(fp[0],"%s","\n");
				fclose(fp[0]);
				break;
			case 2:
				fp[1] = fopen("Deepakmedicalstore.txt","a");
				fprintf(fp[1],"%s",medicine);
				fprintf(fp[1],"%s","	");
				fprintf(fp[1],"%s",quantity);
				fprintf(fp[1],"%s","	");
				fprintf(fp[1],"%s",price);
				fprintf(fp[1],"%s","\n");
				fclose(fp[1]);
				break;
			case 3:
				fp[2] = fopen("MedCart.txt","a");
				fprintf(fp[2],"%s",medicine);
				fprintf(fp[2],"%s","	");
				fprintf(fp[2],"%s",quantity);
				fprintf(fp[2],"%s","	");
				fprintf(fp[2],"%s",price);
				fprintf(fp[2],"%s","\n");
				fclose(fp[2]);
				break;
			case 4:
				fp[3] = fopen("NarayandasPharmacy.txt","a");
				fprintf(fp[3],"%s",medicine);
				fprintf(fp[3],"%s","	");
				fprintf(fp[3],"%s",quantity);
				fprintf(fp[3],"%s","	");
				fprintf(fp[3],"%s",price);
				fprintf(fp[3],"%s","\n");
				fclose(fp[3]);
				break;
			case 5:
				fp[4] = fopen("ParasMedical.txt","a");
				fprintf(fp[4],"%s",medicine);
				fprintf(fp[4],"%s","	");
				fprintf(fp[4],"%s",quantity);
				fprintf(fp[4],"%s","	");
				fprintf(fp[4],"%s",price);
				fprintf(fp[4],"%s","\n");
				fclose(fp[4]);
				break;
			case 6:
				fp[5] = fopen("ParthPharmacy.txt","a");
				fprintf(fp[5],"%s",medicine);
				fprintf(fp[5],"%s","	");
				fprintf(fp[5],"%s",quantity);
				fprintf(fp[5],"%s","	");
				fprintf(fp[5],"%s",price);
				fprintf(fp[5],"%s","\n");
				fclose(fp[5]);
				break;
			case 7:
				fp[6] = fopen("PlanetHealth.txt","a");
				fprintf(fp[6],"%s",medicine);
				fprintf(fp[6],"%s","	");
				fprintf(fp[6],"%s",quantity);
				fprintf(fp[6],"%s","	");
				fprintf(fp[6],"%s",price);
				fprintf(fp[6],"%s","\n");
				fclose(fp[6]);
				break;
			case 8:
				fp[7] = fopen("SunnyMedical.txt","a");
				fprintf(fp[7],"%s",medicine);
				fprintf(fp[7],"%s","	");
				fprintf(fp[7],"%s",quantity);
				fprintf(fp[7],"%s","	");
				fprintf(fp[7],"%s",price);
				fprintf(fp[7],"%s","\n");
				fclose(fp[7]);
				break;
			case 9:
				fp[8] = fopen("SunriseMedical.txt","a");
				fprintf(fp[8],"%s",medicine);
				fprintf(fp[8],"%s","	");
				fprintf(fp[8],"%s",quantity);
				fprintf(fp[8],"%s","	");
				fprintf(fp[8],"%s",price);
				fprintf(fp[8],"%s","\n");
				fclose(fp[8]);
				break;
			default:
				printf("Enter a valid choice:");
				break;
		}
		printf("\nThe data has been added in the file.");
		printf("\n\nPress 1 to continue or 2 to exit.\n");
		scanf("%d",&finalChoice);
	}
	if(finalChoice == 2)
	{
		system("cls");
		for(i=0; i<35; i++)
  		{
  			system("color B");
	    	setxy(i, 4);
	    	printf(".....THANK YOU.....");
	    	setxy(i-3, 4); //For clearing previous position of arrow
			Sleep(100);
		}
	}
}


void displayBorder()
{
	system("color B");
	int i;
	for(i=0;i<30;i++)
	{
		printf("%c",223);
	}
}

void setxy (int x, int y)
{
 c.X = x; c.Y = y; // Set X and Y coordinates
 SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}


